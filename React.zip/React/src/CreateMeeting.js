import React, { useEffect, useState } from "react";
import {MeetingProvider} from "@videosdk.live/react-sdk";
import { getToken, createMeetingApi } from "./api";
import MeetingView from "./MeetingView";


const CreateMeeting = () => {
  const [token, setToken] = useState(null);
  const [meetingId, setMeetingId] = useState(null);
  const [meetingName, setMeetingName] = useState('Participant Name');
  const getMeetingAndToken = async () => {
    const token = await getToken();
    const meetingId = await createMeetingApi({ token });
    setToken(token);
    setMeetingId(meetingId);
  };

  useEffect(getMeetingAndToken, []);

  return token && meetingId ? (
    <MeetingProvider
      config={{
        meetingId,
        micEnabled: true,
        webcamEnabled: false,
        meetingName,
      }}
      token={token}
    >
     <MeetingView />
    </MeetingProvider>
  ) : (
    <p>loading... </p>
  );
};

export default CreateMeeting;
