import React, { useRef, useEffect } from "react";
import { useMeeting, useParticipant } from "@videosdk.live/react-sdk";
import ParticipantView from "./ParticipantView";

const chunk = (arr) => {
    const newArr = [];
    while (arr.length) newArr.push(arr.splice(0, 3));
    return newArr;
};

// const ParticipantView = ({ participantId }) => {
    
//     const webcamRef = useRef(null);
//     const micRef = useRef(null);
//     const screenShareRef = useRef(null);
//     const onStreamEnabled = (stream) => { };
//     const onStreamDisabled = (stream) => { };

//     const {
//         displayName,
//         webcamStream,
//         micStream,
//         screenShareStream,
//         webcamOn,
//         micOn,
//         screenShareOn,
//         isLocal,
//         isActiveSpeaker,
//         isMainParticipant,
//     } = useParticipant(participantId, { onStreamEnabled, onStreamDisabled });

//     useEffect(() => {
//         if (micRef.current) {
//             if (micOn) {
//                 const mediaStream = new MediaStream();
//                 mediaStream.addTrack(micStream.track);

//                 micRef.current.srcObject = mediaStream;
//                 micRef.current
//                     .play()
//                     .catch((error) =>
//                         console.error("videoElem.current.play() failed", error)
//                     );
//             } else {
//                 micRef.current.srcObject = null;
//             }
//         }
//     }, [micStream, micOn]);
//     return <>
//         <audio ref={micRef} autoPlay />
//     </>
// }

const ParticipantsView = () => {
    const { participants } = useMeeting();
    return (
        <div
            style={{
                display: "flex",
                flexWrap: "wrap",
                flexDirection: "column",
            }}
        >
            <span> Participants</span>
            <div>{JSON.stringify(participants, null, 2)}</div>
            {chunk([...participants.keys()]).map((k) => (
                <div style={{ display: "flex" }}>
                    {k.map((l) => (
                        <ParticipantView key={l} participantId={l} />
                    ))}
                </div>
            ))}
        </div>
    );
};


export default ParticipantsView;