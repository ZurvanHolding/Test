
// import {
//   BrowserRouter as Router,
//   Switch,
//   Route,
//   Link
// } from "react-router-dom";
// import React from "react";
// import CreateMeeting from "./CreateMeeting";
// import JoinMeeting from "./JoinMeeting";

// const App = () => {
//   // const [token, setToken] = useState(null);
//   // const [meetingId, setMeetingId] = useState(null);
//   // const [meetingName, setMeetingName] = useState('Participant Name');
//   // const getMeetingAndToken = async () => {
//   //   debugger;
//   //   const token = await getToken();
//   //   const meetingId = await createMeeting({ token });
//   //   setToken(token);
//   //   setMeetingId(meetingId, 'sssssssssssssssssssssssssssssssssssssssssssss');
//   //   console.log(meetingId);
//   // };

//   // useEffect(getMeetingAndToken, []);

//   return <Router>
//     <div>
//       <ul>
//         <li>
//           <Link to="/JoinMeeting">JoinMeeting</Link>
//         </li>
//         <li>
//           <Link to="/CresteMeeting">CresteMeeting</Link>
//         </li>
//       </ul>

//       <hr />

//       {/*
//     A <Switch> looks through all its children <Route>
//     elements and renders the first one whose path
//     matches the current URL. Use a <Switch> any time
//     you have multiple routes, but you want only one
//     of them to render at a time
//   */}
//       <Switch>
//         <Route exact path="/">
//         </Route>
//         <Route path="/JoinMeeting">
//           <JoinMeeting />
//         </Route>
//         <Route path="/CresteMeeting">
//           <CreateMeeting />
//         </Route>
//       </Switch>
//     </div>
//   </Router>


// };

// export default App;
