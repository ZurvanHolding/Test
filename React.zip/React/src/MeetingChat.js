
const MeetingChat = ({ tollbarHeight }) => {
    const { sendChatMessage, messages } = useMeeting();
    const [message, setMessage] = useState("");
  
    return (
      <div
        style={{
          marginLeft: borderRadius,
          width: 400,
          backgroundColor: primary,
          overflowY: "scroll",
          borderRadius,
          height: `calc(100vh - ${tollbarHeight + 2 * borderRadius}px)`,
          padding: borderRadius,
        }}
      >
        <Title title={"Chat"} />
  
        <div style={{ display: "flex" }}>
          <input
            value={message}
            onChange={(e) => {
              const v = e.target.value;
              setMessage(v);
            }}
          />
          <button
            className={"button default"}
            onClick={() => {
              const m = message;
  
              if (m.length) {
                sendChatMessage(m);
  
                setMessage("");
              }
            }}
          >
            Send
          </button>
        </div>
        <div>
          {messages?.map((message, i) => {
            const { senderId, senderName, text, timestamp } = message;
  
            return (
              <div
                style={{
                  margin: 8,
                  backgroundColor: "darkblue",
                  borderRadius: 8,
                  overflow: "hidden",
                  padding: 8,
                  color: "#fff",
                }}
                key={i}
              >
                <p style={{ margin: 0, padding: 0, fontStyle: "italic" }}>
                  {senderName}
                </p>
                <h3 style={{ margin: 0, padding: 0, marginTop: 4 }}>{text}</h3>
                <p
                  style={{
                    margin: 0,
                    padding: 0,
                    opacity: 0.6,
                    marginTop: 4,
                  }}
                >
                  {formatAMPM(new Date(parseInt(timestamp)))}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  