import { ExampleComponent } from "./webrtc";


const App=()=>{
  return <ExampleComponent text="aaaaaaaaaaaa"/>;
}
export default App;