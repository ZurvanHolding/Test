import { MeetingProvider } from "@videosdk.live/react-sdk";
import { useEffect, useState } from "react";
import { useAppContext } from "../Provider/AppContext";
import Api from '../Provider/Api'
import { useRouter } from "next/router";
import { MeetingView } from "./MeetingView";
import { Notification } from "./Notification";



const CreateMeeting = () => {
  const router = useRouter();
  const { token } = useAppContext();
  const [meetingId, setMeetingId] = useState(null);
  const meetingName = 'Participant Name';

  const manegmentMeeting = async (code) => {
    if (code == '' || typeof code == 'undefined') {
      const metId = await Api.createMeeting({ token });
      debugger;
        setMeetingId(metId);
    }
    else {
      setMeetingId(code);
      await Api.joinMeeting({ token, meetingId });
    }
  };
  useEffect(() => {
    if (token == null)
      router.push('/');
    const { code } = router.query;
    manegmentMeeting(code);
  }, []);
  return token && meetingId ? (
    <MeetingProvider
      config={{
        meetingId,
        micEnabled: true,
        webcamEnabled: false,
        meetingName,
      }}
      token={token}
    >
      <MeetingView />
      <Notification />

    </MeetingProvider>
  ) : (
    <p>loading... </p>
  );
};

export default CreateMeeting;


