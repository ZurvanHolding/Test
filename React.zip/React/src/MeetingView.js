import React, { useEffect, useRef, useState } from "react";
import {
    MeetingProvider,
    MeetingConsumer,
    useMeeting,
    useParticipant,
} from "@videosdk.live/react-sdk";
import { getToken, validateMeeting, createMeeting } from "./api";
import ParticipantsView from "./ParticipantsView";
const ExternalVideo = () => {
    const [{ link, playing }, setVideoInfo] = useState({
        link: null,
        playing: false,
    });
    return "";
}
function MeetingView() {
    function onParticipantJoined(participant) {
        console.log(" onParticipantJoined", participant);
    }
    function onParticipantLeft(participant) {
        console.log(" onParticipantLeft", participant);
    }
    const onSpeakerChanged = (activeSpeakerId) => {
        console.log(" onSpeakerChanged", activeSpeakerId);
    };
    function onPresenterChanged(presenterId) {
        console.log(" onPresenterChanged", presenterId);
    }
    function onMainParticipantChanged(participant) {
        console.log(" onMainParticipantChanged", participant);
    }
    function onEntryRequested(participantId, name) {
        console.log(" onEntryRequested", participantId, name);
    }
    function onEntryResponded(participantId, name) {
        console.log(" onEntryResponded", participantId, name);
    }
    function onRecordingStarted() {
        console.log(" onRecordingStarted");
    }
    function onRecordingStopped() {
        console.log(" onRecordingStopped");
    }
    function onChatMessage(data) {
        console.log(" onChatMessage", data);
    }
    function onMeetingJoined() {
        console.log("onMeetingJoined");
    }
    function onMeetingLeft() {
        console.log("onMeetingLeft");
    }
    const onLiveStreamstarted = (data) => {
        console.log("onLiveStreamstarted example", data);
    };
    const onLiveStreamStopped = (data) => {
        console.log("onLiveStreamStopped example", data);
    };

    const onVideoStateChanged = (data) => {
        console.log("onVideoStateChanged", data);
    };
    const onVideoSeeked = (data) => {
        console.log("onVideoSeeked", data);
    };

    const {
        meetingId,
        meeting,
        // localParticipant,
        // mainParticipant,
        // activeSpeakerId,
        participants,
        isRecording,
        // presenterId,
        // localMicOn,
        // localWebcamOn,
        // localScreenShareOn,
        messages,
        //
        join,
        leave,

        startRecording,
        stopRecording,
        // //
        sendChatMessage,
        // respondEntry,

        toggleMic,
        toggleWebcam,

        toggleScreenShare,
        startVideo,
        stopVideo,
        resumeVideo,
        pauseVideo,
        seekVideo,

        startLivestream,
        stopLivestream,
        isLiveStreaming,
    } = useMeeting({
        onParticipantJoined,
        onParticipantLeft,
        onSpeakerChanged,
        onPresenterChanged,
        onMainParticipantChanged,
        onEntryRequested,
        onEntryResponded,
        onRecordingStarted,
        onRecordingStopped,
        onChatMessage,
        onMeetingJoined,
        onMeetingLeft,
        onLiveStreamstarted,
        onLiveStreamStopped,
        onVideoStateChanged,
        onVideoSeeked,
    });

    const handlestartVideo = () => {
        console.log("handlestartVideo");

        startVideo({
            link: "https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4",
        });
    };

    const handlestopVideo = () => {
        stopVideo();
    };

    const handleresumeVideo = () => {
        resumeVideo();
    };
    const handlepauseVideo = () => {
        pauseVideo({ currentTime: 2 });
    };
    const handlesseekVideo = () => {
        seekVideo({ currentTime: 5 });
    };
    const handleStartLiveStream = () => {
        startLivestream([
            {
                url: "rtmp://a.rtmp.youtube.com/live2",
                streamKey: "key",
            },
        ]);
    };

    const handleStopLiveStream = () => {
        stopLivestream();
    };
    const handleStartRecording = () => {
        startRecording();
    };
    const handleStopRecording = () => {
        stopRecording();
    };
    const[mId, setMId] = useState(meetingId);
    const tollbarHeight = 60;

    return (
        <div
            style={{
                display: "flex",
                flexDirection: "column",
                backgroundColor: "#D6E9FE",
            }}
        >
            <div style={{ height: tollbarHeight }}>
                <input type="text"  value={mId} onChange={e => setMId(e.target.value)}/>
                <button className={"button blue"} onClick={join}>
                    JOIN
                </button>
                <button className={"button red"} onClick={leave}>
                    LEAVE
                </button>
                <button className={"button blue"} onClick={toggleMic}>
                    toggleMic
                </button>
                <button className={"button blue"} onClick={toggleWebcam}>
                    toggleWebcam
                </button>
                <button className={"button blue"} onClick={toggleScreenShare}>
                    toggleScreenShare
                </button>
                <button className={"button blue"} onClick={handlestartVideo}>
                    startVideo
                </button>
                <button className={"button blue"} onClick={handlestopVideo}>
                    stopVideo
                </button>
                <button className={"button blue"} onClick={handleresumeVideo}>
                    resumeVideo
                </button>
                <button className={"button blue"} onClick={handlepauseVideo}>
                    pauseVideo
                </button>
                <button className={"button blue"} onClick={handlesseekVideo}>
                    seekVideo
                </button>

                <button className={"button blue"} onClick={handleStartLiveStream}>
                    Start Live Stream
                </button>
                <button className={"button blue"} onClick={handleStopLiveStream}>
                    Stop Live Stream
                </button>
                <button className={"button blue"} onClick={handleStartRecording}>
                    start recording
                </button>
                <button className={"button blue"} onClick={handleStopRecording}>
                    stop recording
                </button>
            </div>
            <div style={{ display: "flex", flex: 1 }}>
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        position: "relative",
                        flex: 1,
                        overflowY: "scroll",
                        height: `calc(100vh - ${tollbarHeight}px)`,
                    }}
                >
                    <ExternalVideo />
                    <ParticipantsView />
                </div>
                {/* <MeetingChat tollbarHeight={tollbarHeight} /> */}
            </div>
        </div>
    );
};

export default MeetingView;